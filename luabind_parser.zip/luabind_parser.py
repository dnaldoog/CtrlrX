#!/usr/bin/env python3
"""
Ctrlr luabind parser (V4)
- module-aware
- static / instance / enum support
- wrapper merging (LClass -> Class)
- fast and stable
"""

import re
import sys
from pathlib import Path
from collections import defaultdict
from xml.etree.ElementTree import Element, SubElement, ElementTree, indent

# ------------------------------------------------------------
# Defaults
# ------------------------------------------------------------

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_SRC = ROOT / "Source"
DEFAULT_OUT = ROOT / "Source" / "Resources" / "XML" / "LuaAPI.xml"

WRAPPER_PREFIXES = ("L",)
FORCE_STATIC_CLASSES = {"CtrlrLuaUtils"}

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

def strip_ns(name: str) -> str:
    return name.split("::")[-1]

def clean_args(sig: str) -> str:
    if not sig or sig.strip() in ("void", ""):
        return "()"
    sig = re.sub(r'=[^,)]+', '', sig)
    sig = re.sub(r'\b(const|static|inline|virtual|override|noexcept)\b', '', sig)
    sig = sig.replace("&", "").replace("*", "")
    parts = [p.strip().split()[-1] for p in sig.split(",") if p.strip()]
    return f"({', '.join(parts)})"

def extract_bracket_block(text: str, start: int) -> str | None:
    depth = 0
    in_string = False
    esc = False

    for i in range(start, len(text)):
        c = text[i]

        if esc:
            esc = False
            continue
        if c == "\\":
            esc = True
            continue
        if c == '"':
            in_string = not in_string
            continue
        if in_string:
            continue

        if c == "[":
            depth += 1
        elif c == "]":
            depth -= 1
            if depth == 0:
                return text[start + 1 : i]

    return None

# ------------------------------------------------------------
# Parser
# ------------------------------------------------------------

class LuabindParserV4:
    def __init__(self):
        self.classes = {}

    # -----------------------------

    def parse_cpp_file(self, text: str):
        for m in re.finditer(r'(?:luabind::)?module\s*\([^)]*\)\s*\[', text):
            body = extract_bracket_block(text, m.end() - 1)
            if body:
                self.parse_module(body)

    # -----------------------------

    def parse_module(self, content: str):
        chunks = re.split(r'(class_<\s*[\w:]+)', content)
        for i in range(1, len(chunks), 2):
            block = chunks[i] + chunks[i + 1]
            self.parse_class(block)

    # -----------------------------

    def parse_class(self, block: str):
        header = re.search(
            r'class_<\s*([\w:]+)[^>]*>\s*(?:\(\s*"([^"]+)"\s*\))?',
            block,
            re.S,
        )
        if not header:
            return

        cpp = strip_ns(header.group(1))
        lua = header.group(2) or cpp

        cls = self.classes.setdefault(
            lua,
            {
                "cpp": cpp,
                "methods": defaultdict(list),
                "static": defaultdict(list),
                "enums": {},
            },
        )

        scope_pos = block.find(".scope")

        instance_part = block[:scope_pos] if scope_pos != -1 else block

        # ---------- instance methods ----------
        for m in re.finditer(r'\.def\s*\(\s*"([^"]+)"\s*,\s*([^,)]+)', instance_part):
            name, sig = m.groups()
            cls["methods"][name].append(clean_args(sig))

        # ---------- static methods ----------
        if scope_pos != -1:
            scope_body = extract_bracket_block(block, scope_pos + len(".scope") - 1)
            if scope_body:
                for m in re.finditer(r'def\s*\(\s*"([^"]+)"\s*,\s*([^,)]+)', scope_body):
                    name, sig = m.groups()
                    cls["static"][name].append(clean_args(sig))

        # ---------- enums ----------
        for e in re.finditer(r'\.enum_\s*\(\s*"([^"]+)"\s*\)\s*\[', block):
            ename = e.group(1)
            body = extract_bracket_block(block, e.end() - 1)
            if not body:
                continue
            values = re.findall(r'value\s*\(\s*"([^"]+)"', body)
            cls["enums"][ename] = values

    # -----------------------------

    def merge_wrappers(self):
        for name in list(self.classes.keys()):
            for p in WRAPPER_PREFIXES:
                if name.startswith(p) and name[len(p):] in self.classes:
                    base = self.classes[name[len(p):]]
                    wrap = self.classes[name]

                    for k in ("methods", "static"):
                        for m, sigs in wrap[k].items():
                            base[k][m].extend(sigs)

                    base["enums"].update(wrap["enums"])
                    del self.classes[name]

    # -----------------------------

    def force_static(self):
        for name, cls in self.classes.items():
            if name in FORCE_STATIC_CLASSES or cls["cpp"] in FORCE_STATIC_CLASSES:
                for m, sigs in cls["methods"].items():
                    cls["static"][m].extend(sigs)
                cls["methods"].clear()

    # -----------------------------

    def write_xml(self, out_file: Path):
        root = Element("LuaAPI")

        for name in sorted(self.classes):
            c = self.classes[name]
            ce = SubElement(root, "class", {"name": name, "cpp_name": c["cpp"]})

            if c["methods"]:
                me = SubElement(ce, "methods")
                for m, sigs in sorted(c["methods"].items()):
                    for i, args in enumerate(sigs, 1):
                        attr = {"name": m, "type": "instance", "args": args}
                        if len(sigs) > 1:
                            attr["overload"] = str(i)
                        SubElement(me, "method", attr)

            if c["static"]:
                se = SubElement(ce, "static_methods")
                for m, sigs in sorted(c["static"].items()):
                    for i, args in enumerate(sigs, 1):
                        attr = {"name": m, "type": "static", "args": args}
                        if len(sigs) > 1:
                            attr["overload"] = str(i)
                        SubElement(se, "method", attr)

            if c["enums"]:
                ee = SubElement(ce, "enums")
                for en, vals in c["enums"].items():
                    ene = SubElement(ee, "enum", {"name": en})
                    for v in vals:
                        SubElement(ene, "value", {"name": v})

        indent(root, space="  ")
        out_file.parent.mkdir(parents=True, exist_ok=True)
        ElementTree(root).write(out_file, encoding="utf-8", xml_declaration=True)

# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

if __name__ == "__main__":
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_SRC
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_OUT

    parser = LuabindParserV4()

    for cpp in src.rglob("*.cpp"):
        try:
            parser.parse_cpp_file(cpp.read_text(encoding="utf-8", errors="ignore"))
        except Exception as e:
            print(f"[WARN] {cpp}: {e}")

    parser.merge_wrappers()
    parser.force_static()
    parser.write_xml(out)

    print(f"[OK] Lua API generated → {out}")
    print(f"[OK] Classes found: {len(parser.classes)}")
